-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: kyranis_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB-1:10.4.32+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Εργασία'),(2,'Προσωπικά'),(3,'Εκπαίδευση'),(4,'Χόμπι'),(5,'Κοινωνικά');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `list_users`
--

DROP TABLE IF EXISTS `list_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `list_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tasksListId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `tasksListId` (`tasksListId`),
  KEY `userId` (`userId`),
  CONSTRAINT `list_users_ibfk_1` FOREIGN KEY (`tasksListId`) REFERENCES `tasks_list` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `list_users_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `list_users`
--

LOCK TABLES `list_users` WRITE;
/*!40000 ALTER TABLE `list_users` DISABLE KEYS */;
INSERT INTO `list_users` VALUES (34,60,42),(35,61,42),(36,62,42),(37,63,42),(38,61,44),(39,61,43),(40,61,48),(41,60,45),(42,60,47),(43,63,46),(44,63,44),(45,64,43),(46,65,44),(47,66,45),(48,67,46),(49,68,47),(50,69,48);
/*!40000 ALTER TABLE `list_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statuses`
--

DROP TABLE IF EXISTS `statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statuses`
--

LOCK TABLES `statuses` WRITE;
/*!40000 ALTER TABLE `statuses` DISABLE KEYS */;
INSERT INTO `statuses` VALUES (1,'Νέα'),(2,'Σε εξέλιξη'),(3,'Ολοκληρωμένη');
/*!40000 ALTER TABLE `statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `tasksListId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `tasksListId` (`tasksListId`),
  KEY `userId` (`userId`),
  CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`tasksListId`) REFERENCES `tasks_list` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tasks_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES (117,'Ανάλυση Δεδομένων',63,42),(118,'Σύνταξη Εκθέσεων',63,42),(119,'Αξιολόγηση Εκπαιδευτικών Προγραμμάτων',63,42),(120,'Αναφορές',62,42),(121,'Απάντηση σε σημαντικά emails',62,42),(122,'Διαχείριση Χρόνου',62,42),(123,'Ανάπτυξη νέων χαρακτηριστικών εφαρμογής',61,42),(124,'Unit testing',61,42),(125,'Code review',61,42),(126,'Documentation',61,42),(127,'Αναβάθμιση Βιβλιοθηκών',60,42),(128,'Διόρθωση Σφαλμάτων',60,42),(129,'Βελτιστοποίηση Κώδικα',60,42),(130,'Ασφάλεια',60,42),(131,'Τεκμηρίωση',60,42),(132,'Ανάλυση απαιτήσεων',64,43),(133,'Οργάνωση των δεδομένων σε πίνακες',64,43),(134,'Κανονικοποίηση',64,43),(135,'Καταγραφή διαδρομών',65,44),(136,'Ψάξιμο τοπικών μονοπατιών',65,44),(137,'Εξερεύνηση νέων περιοχών',65,44),(138,'Ανάλυση Αποτελεσμάτων Εκπαιδευτικών Προγραμμάτων',63,44),(139,'Συμμετοχή σε Καθαρισμούς Περιβάλλοντος',66,45),(140,'Διοργάνωση Εκδηλώσεων Κοινότητας',66,45),(141,'Οργάνωση Προσωπικών Αντικειμένων',67,46),(142,'Φροντίδα Κατοικιδίων',67,46),(143,'Συντήρηση Κουζίνας',67,46),(144,'Ορισμός Στόχων Ποιότητας',68,47),(145,'Ανάλυση Δεδομένων Ποιότητας',68,47),(146,'Σχεδιασμός και Εφαρμογή Βελτιώσεων',68,47),(147,'Παρακολούθηση και Αξιολόγηση',68,47),(148,'Εκπαίδευση Προσωπικών Δεξιοτήτων',69,48),(149,'Στόχοι και Σχέδια',69,48);
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks_list`
--

DROP TABLE IF EXISTS `tasks_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasks_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `categoryId` int(11) NOT NULL,
  `statusId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `categoryId` (`categoryId`),
  KEY `statusId` (`statusId`),
  KEY `userId` (`userId`),
  CONSTRAINT `tasks_list_ibfk_1` FOREIGN KEY (`categoryId`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tasks_list_ibfk_2` FOREIGN KEY (`statusId`) REFERENCES `statuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tasks_list_ibfk_3` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks_list`
--

LOCK TABLES `tasks_list` WRITE;
/*!40000 ALTER TABLE `tasks_list` DISABLE KEYS */;
INSERT INTO `tasks_list` VALUES (60,'Εργασίες Συντήρησης',1,1,42),(61,'Στόχοι Εβδομάδας',1,1,42),(62,'Επείγουσες Εργασίες',1,1,42),(63,'Αναφορές και Αναλύσεις',3,2,42),(64,'Σχεδίαση Βάσης Δεδομένων',1,2,43),(65,'Εξερεύνηση νέων διαδρομών για ποδηλασία',4,1,44),(66,'Συμμετοχή σε Κοινωνικές Εκδηλώσεις και Πρωτοβουλίες',5,2,45),(67,'Καθημερινές Εργασίες',2,1,46),(68,'Βελτίωση Διαδικασιών Ποιότητας',1,1,47),(69,'Προσωπική Ανάπτυξη',2,1,48);
/*!40000 ALTER TABLE `tasks_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_users`
--

DROP TABLE IF EXISTS `team_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teamId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `teamId` (`teamId`),
  KEY `userId` (`userId`),
  CONSTRAINT `team_users_ibfk_1` FOREIGN KEY (`teamId`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `team_users_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_users`
--

LOCK TABLES `team_users` WRITE;
/*!40000 ALTER TABLE `team_users` DISABLE KEYS */;
INSERT INTO `team_users` VALUES (42,22,42),(43,22,44),(44,22,43),(45,23,45),(46,23,42),(47,23,47),(48,22,48),(49,24,42),(50,24,46),(51,24,44);
/*!40000 ALTER TABLE `team_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES (22,'Ομάδα Ανάπτυξης'),(23,'Ομάδα Ποιότητας'),(24,'Ομάδα Υποστήριξης');
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `password` varchar(60) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `role` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (42,'admin','$2y$10$YgY/Xxer6uQ.orEmpM8acu6cBzlzd1bBKYQyBP0.8uSqE4Deih5hq','','admin@mail.com',0),(43,'zenith','$2y$10$RolNYv2Cxgo4HN3SPZdSCO27qw1Qp4zU6kw/wkX3QjubgUOUGYwZ.','','zenith@mail.com',1),(44,'quasar','$2y$10$WZzOLZxsAOI98G5PaO1OLuGX/WwsceNx0DP0TBvFqVgeGIq0fF1wC','','quasar@mail.com',1),(45,'lumina','$2y$10$MySu7faaWmixMkUNs3f.HOUNS60KlWt9vL44DO/ds.2Dgrv5.MO1W','','lumina@mail.com',1),(46,'eclipse','$2y$10$gLnghAsGs9vuGHYqjRGt3OwnMce4APdzVGuTXzsgbU6Mss1OWl5Wy','','eclipse@mail.com',1),(47,'infinity','$2y$10$rjKkavXpyuJQ7S4TXjBOGuZmtyk.YUXrg/yuEshVx6k56vnYsrb..','','infinity@mail.com',1),(48,'orion','$2y$10$CPP2FcUACyqfwCtgVNRyxedzO2e8.Dz2R8Rn/5H9QOiv4bvQ7aPMm','','orion@gmail.com',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-25 18:33:41
